import { Routes, Route } from "react-router-dom";
import Cart from "./pages/Cart";
import ManageDiscount from "./pages/ManageDiscount";

function App() {

  return (
    <>
      <Routes>
        <Route path="/cart" element={<Cart />} />
        <Route path="/managediscount" element={<ManageDiscount />} />
      </Routes>
    </>
  )
}

export default App
