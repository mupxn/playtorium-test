import {
    Button,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    IconButton,
} from "@mui/material"
import AddIcon from "@mui/icons-material/Add"
import EditIcon from "@mui/icons-material/Edit"
import DeleteIcon from "@mui/icons-material/Delete"
import axios from "axios"
import { useEffect, useState } from "react"
import AddDiscount from "../component/AddDiscount"

interface DiscountItem {
    id: number
    name: string
    campaigns: string
    category: string
    details: string
    value?: number
    itemCategory?: string
    discountValue?: number
    maxDiscountPercent?: number
    minimumSpend?: number
    discountAmount?: number
}

const ManageDiscount = () => {
    const [discountData, setDiscountData] = useState<DiscountItem[]>([])
    const [openAddDialog, setOpenAddDialog] = useState(false)
    const dataCampaigns = async () => {
        try {
            const response = await axios.get('http://localhost:5000/discounts')
            console.log(response.data);
            setDiscountData(response.data)
        } catch (error) {
            console.log(error);
        }
    }
    const handleOpenAddDialog = () => {
        setOpenAddDialog(true)
    }
    const handleCloseAddDialog = () => {
        setOpenAddDialog(false)
    }
    const handleDeleteData = async(id: number) => {
        console.log(id);
        try {
            const response = await axios.delete(`http://localhost:5000/discounts/${id}`);
            console.log("Delete successful:", response.data);
            // หลังจากลบเสร็จ คุณสามารถทำการรีเฟรชข้อมูลหรือลบจาก state
        } catch (error) {
            console.error("Error deleting item:", error);
        }
        dataCampaigns()
    }
    useEffect(() => {
        dataCampaigns()
    }, [])

    return (
        <div className="manage-discount-page" style={{ maxWidth: '1200px', margin: '0 auto', padding: '50px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <h1>จัดการส่วนลด</h1>
                <Button
                    variant="contained"
                    startIcon={<AddIcon />}
                    onClick={handleOpenAddDialog}
                >
                    เพิ่มส่วนลดใหม่
                </Button>
            </div>

            <TableContainer component={Paper} sx={{ boxShadow: "none", border: "1px solid #e0e0e0", marginTop:'20px' }}>
                <Table>
                    <TableHead>
                        <TableRow sx={{ backgroundColor: "#f5f5f5" }}>
                            <TableCell>Name</TableCell>
                            <TableCell>Campaigns</TableCell>
                            <TableCell>Category</TableCell>
                            <TableCell>Description</TableCell>
                            <TableCell>Manage</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {discountData.map((row) => (
                            <TableRow key={row.id} >
                                <TableCell>{row.name}</TableCell>
                                <TableCell>{row.campaigns}</TableCell>
                                <TableCell>{row.category}</TableCell>
                                <TableCell>{row.details}</TableCell>
                                <TableCell>
                                        <IconButton aria-label="Example" sx={{ border: "1px solid #e0e0e0" }} onClick={() => handleDeleteData(row.id)}>
                                            <DeleteIcon fontSize="small"/>
                                        </IconButton>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
            <AddDiscount open={openAddDialog} onClose={handleCloseAddDialog} getData={dataCampaigns} />
        </div>
    )
}

export default ManageDiscount
