export interface DiscountItem {
    id: number
    name: string
    type: string
    category: string
    details: string
    isActive: boolean
  }